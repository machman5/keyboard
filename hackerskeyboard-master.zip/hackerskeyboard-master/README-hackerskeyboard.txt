See https://github.com/klausw/hackerskeyboard/ for more details about
this project.

Build instructions:
  https://github.com/klausw/hackerskeyboard/wiki/BuildingFromSource

If you're planning to make changes that you intend to contribute to the
project, please get in touch first, the code is currently in flux and
there may be active refactorings that could break whatever you are
working on.

Project contact: pocketworkstation@gmail.com
